﻿using System;
using Infosys.TechHubDB.DataAccessLayer;
using Infosys.TechHubDB.DataAccessLayer.Models;

namespace Infosys.TechHub.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            TechHubRepository repository = new TechHubRepository();

            //Categories categoryOne = new Categories();
            //categoryOne.CategoryName = "Angular 6";
            //categoryOne.CategoryDescription = "This is Angular 6.";

            //bool result = repository.AddCategory(categoryOne);
            //if (result)
            //{
            //    Console.WriteLine("Product details added successfully!");
            //}
            //else
            //{
            //    Console.WriteLine("Some error occurred. Try again!!");
            //}

            //Categories updatecategoryOne = new Categories();
            //updatecategoryOne.CategoryId = 2;
            //updatecategoryOne.CategoryName = "Node JS";
            //updatecategoryOne.CategoryDescription = "This is Node JS.";

            //bool result = repository.UpdateCategory(updatecategoryOne);
            //if (result)
            //{
            //    Console.WriteLine("Product details Updated successfully!");
            //}
            //else
            //{
            //    Console.WriteLine("Some error occurred. Try again!!");
            //}

            //Categories deletecategoryOne = new Categories();
            //deletecategoryOne.CategoryId = 2;
            //deletecategoryOne.CategoryName = "Node JS";
            //deletecategoryOne.CategoryDescription = "This is Node JS.";

            //bool result = repository.DeleteCategory(deletecategoryOne);
            //if (result)
            //{
            //    Console.WriteLine("Product details Deleted successfully!");
            //}
            //else
            //{
            //    Console.WriteLine("Some error occurred. Try again!!");
            //}

            //byte categoryId = 2;
            //Questions question = repository.GetQuestion(categoryId);
            //if (question == null)
            //{
            //    Console.WriteLine("No product details available");
            //}
            //else
            //{
            //    Console.WriteLine("{0,-15}{1,-30}{2,-15}{3,-10}{4}", "QuestionId", "QuestionDescription");
            //    Console.WriteLine("---------------------------------------------------------------------------------------");
            //    Console.WriteLine("{0,-15}{1,-30}{2,-15}{3,-10}{4}", question.QuestionId, question.QuestionDescription);
            //}

            //byte categoryId = 2;
            //string lstCategory = repository.GetQuestionByCategoryID(categoryId);
            //if (lstCategory == null)
            //{
            //    Console.WriteLine("No category available under the category = " + categoryId);
            //}
            //else
            //{
            //    Console.WriteLine("{0,-15}{1,-30}{2,-15}{3,-10}{4}", "QuestionDescription");
            //    Console.WriteLine("---------------------------------------------------------------------------------------");
                
            //        Console.WriteLine("{0,-15}{1,-30}{2,-15}{3,-10}{4}",lstCategory);
               
            //}

            //byte categoryId = 2;
            //string lstBlog = repository.GetBlogByCategoryID(categoryId);
            //if (lstBlog == null)
            //{
            //    Console.WriteLine("No blog available under the category = " + categoryId);
            //}
            //else
            //{
            //    Console.WriteLine("{0,-15}{1,-30}{2,-15}{3,-10}{4}", "QuestionDescription");
            //    Console.WriteLine("---------------------------------------------------------------------------------------");

            //    Console.WriteLine("{0,-15}{1,-30}{2,-15}{3,-10}{4}", lstBlog);

            //}
        }
    }
}
