﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Infosys.TechHubDB.DataAccessLayer.Models;

namespace Infosys.TechHubDB.DataAccessLayer
{
    public class TechHubRepository
    {
        TechHubContext context;
        public TechHubRepository()
        {
            context = new TechHubContext();
        }


        public bool AddCategory(Categories catObj)
        {
            bool status = false;
            try
            {
                context.Categories.Add(catObj);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdateCategory(Categories catObj)
        {
            bool status = false;
            try
            {
                var catObjFromDB = context.Categories.Where(x => x.CategoryId == catObj.CategoryId).Select(x => x).FirstOrDefault();
                catObjFromDB.CategoryName = catObj.CategoryName;
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool DeleteCategory(Categories catObj)
        {
            bool status = false;
            try
            {
                var categoryToBeDeleted = context.Categories.Where(x => x.CategoryId == catObj.CategoryId).FirstOrDefault();
                context.Categories.Remove(categoryToBeDeleted);
                context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }

        public Questions GetQuestion(long questionId)
        {
            Questions question = null;
            try
            {
                question = context.Questions.Where(p => p.QuestionId == questionId).FirstOrDefault();
            }
            catch (Exception ex)
            {
                question = null;
            }
            return question;
        }

        public string GetQuestionByCategoryID(long categoryId)
        {
            try
            {
                var questionDescription = context.Questions.Where(x => x.CategoryId == categoryId).Select(x => x.QuestionDescription).FirstOrDefault();
                return questionDescription;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string GetBlogByCategoryID(long categoryId)
        {
            try
            {
                var blogName = context.Blogs.Where(x => x.CategoryId == categoryId).Select(x => x.BlogName).FirstOrDefault();
                return blogName;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public Blogs GetBlogById(long blogId)
        {
            Blogs blog = null;
            try
            {
                blog = context.Blogs.Where(p => p.BlogId == blogId).FirstOrDefault();
            }
            catch (Exception ex)
            {
                blog = null;
            }
            return blog;
        }


    }
}
