﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class SavedQuestions
    {
        public long SavedQuestionId { get; set; }
        public long? QuestionId { get; set; }
        public string EmailId { get; set; }

        public virtual Users Email { get; set; }
        public virtual Questions Question { get; set; }
    }
}
