﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class Blogs
    {
        public Blogs()
        {
            SavedBlogs = new HashSet<SavedBlogs>();
        }

        public long BlogId { get; set; }
        public string BlogName { get; set; }
        public long? CategoryId { get; set; }
        public string EmailId { get; set; }
        public string BlogDescription { get; set; }
        public byte? Rating { get; set; }

        public virtual Categories Category { get; set; }
        public virtual Users Email { get; set; }
        public virtual ICollection<SavedBlogs> SavedBlogs { get; set; }
    }
}
