﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class Categories
    {
        public Categories()
        {
            Blogs = new HashSet<Blogs>();
            Questions = new HashSet<Questions>();
        }

        public long CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }

        public virtual ICollection<Blogs> Blogs { get; set; }
        public virtual ICollection<Questions> Questions { get; set; }
    }
}
