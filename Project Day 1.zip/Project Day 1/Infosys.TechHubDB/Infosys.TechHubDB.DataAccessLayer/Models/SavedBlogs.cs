﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class SavedBlogs
    {
        public long SavedBlogId { get; set; }
        public long? BlogId { get; set; }
        public string EmailId { get; set; }

        public virtual Blogs Blog { get; set; }
        public virtual Users Email { get; set; }
    }
}
