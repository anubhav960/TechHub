﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class Users
    {
        public Users()
        {
            Answers = new HashSet<Answers>();
            Blogs = new HashSet<Blogs>();
            Questions = new HashSet<Questions>();
            SavedBlogs = new HashSet<SavedBlogs>();
            SavedQuestions = new HashSet<SavedQuestions>();
        }

        public string EmailId { get; set; }
        public string Name { get; set; }
        public decimal PhoneNumber { get; set; }
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }

        public virtual Roles Role { get; set; }
        public virtual ICollection<Answers> Answers { get; set; }
        public virtual ICollection<Blogs> Blogs { get; set; }
        public virtual ICollection<Questions> Questions { get; set; }
        public virtual ICollection<SavedBlogs> SavedBlogs { get; set; }
        public virtual ICollection<SavedQuestions> SavedQuestions { get; set; }
    }
}
