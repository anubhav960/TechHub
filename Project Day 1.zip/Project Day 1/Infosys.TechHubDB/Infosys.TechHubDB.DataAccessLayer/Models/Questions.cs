﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class Questions
    {
        public Questions()
        {
            Answers = new HashSet<Answers>();
            SavedQuestions = new HashSet<SavedQuestions>();
        }

        public long QuestionId { get; set; }
        public string QuestionDescription { get; set; }
        public long? CategoryId { get; set; }
        public string EmailId { get; set; }

        public virtual Categories Category { get; set; }
        public virtual Users Email { get; set; }
        public virtual ICollection<Answers> Answers { get; set; }
        public virtual ICollection<SavedQuestions> SavedQuestions { get; set; }
    }
}
