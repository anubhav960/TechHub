﻿using System;
using System.Collections.Generic;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class Answers
    {
        public long AnswerId { get; set; }
        public string AnswerDescription { get; set; }
        public long? QuestionId { get; set; }
        public string EmailId { get; set; }
        public byte? Rating { get; set; }

        public virtual Users Email { get; set; }
        public virtual Questions Question { get; set; }
    }
}
