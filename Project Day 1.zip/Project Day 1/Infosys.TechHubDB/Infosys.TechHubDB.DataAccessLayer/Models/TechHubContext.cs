﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Infosys.TechHubDB.DataAccessLayer.Models
{
    public partial class TechHubContext : DbContext
    {
        public TechHubContext()
        {
        }

        public TechHubContext(DbContextOptions<TechHubContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Answers> Answers { get; set; }
        public virtual DbSet<Blogs> Blogs { get; set; }
        public virtual DbSet<Categories> Categories { get; set; }
        public virtual DbSet<Questions> Questions { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<SavedBlogs> SavedBlogs { get; set; }
        public virtual DbSet<SavedQuestions> SavedQuestions { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source =(localdb)\\MSSQLLocalDB;Initial Catalog=TechHub;Integrated Security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062");

            modelBuilder.Entity<Answers>(entity =>
            {
                entity.HasKey(e => e.AnswerId)
                    .HasName("pk_AnswerId");

                entity.HasIndex(e => e.AnswerDescription)
                    .HasName("UQ__Answers__A6C67FCEC5FBB995")
                    .IsUnique();

                entity.HasIndex(e => e.AnswerId)
                    .HasName("ix_AnswerId");

                entity.Property(e => e.AnswerDescription)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.Answers)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmailId1");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.Answers)
                    .HasForeignKey(d => d.QuestionId)
                    .HasConstraintName("fk_QuestionId");
            });

            modelBuilder.Entity<Blogs>(entity =>
            {
                entity.HasKey(e => e.BlogId)
                    .HasName("pk_BlogId");

                entity.HasIndex(e => e.BlogName)
                    .HasName("UQ__Blogs__B7F024A4DA274A4E")
                    .IsUnique();

                entity.Property(e => e.BlogDescription).IsUnicode(false);

                entity.Property(e => e.BlogName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Blogs)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("fk_CategoryId1");

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.Blogs)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmailId2");
            });

            modelBuilder.Entity<Categories>(entity =>
            {
                entity.HasKey(e => e.CategoryId)
                    .HasName("pk_CategoryId");

                entity.HasIndex(e => e.CategoryId)
                    .HasName("ix_CategoryId");

                entity.HasIndex(e => e.CategoryName)
                    .HasName("uq_CategoryName")
                    .IsUnique();

                entity.Property(e => e.CategoryDescription)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.CategoryName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Questions>(entity =>
            {
                entity.HasKey(e => e.QuestionId)
                    .HasName("pk_QuestionId");

                entity.HasIndex(e => e.QuestionDescription)
                    .HasName("UQ__Question__2B09E0E89CBC69B0")
                    .IsUnique();

                entity.HasIndex(e => e.QuestionId)
                    .HasName("ix_QuestionId");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.QuestionDescription)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Questions)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("fk_CategoryId");

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.Questions)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmailId");
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("pk_RoleId");

                entity.HasIndex(e => e.RoleName)
                    .HasName("uq_RoleName")
                    .IsUnique();

                entity.Property(e => e.RoleId).ValueGeneratedOnAdd();

                entity.Property(e => e.RoleName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SavedBlogs>(entity =>
            {
                entity.HasKey(e => e.SavedBlogId)
                    .HasName("pk_SavedBlogId");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Blog)
                    .WithMany(p => p.SavedBlogs)
                    .HasForeignKey(d => d.BlogId)
                    .HasConstraintName("fk_BlogId");

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.SavedBlogs)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmailId4");
            });

            modelBuilder.Entity<SavedQuestions>(entity =>
            {
                entity.HasKey(e => e.SavedQuestionId)
                    .HasName("pk_SavedQuestionId");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.SavedQuestions)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmailId3");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.SavedQuestions)
                    .HasForeignKey(d => d.QuestionId)
                    .HasConstraintName("fk_QuestionId1");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.EmailId)
                    .HasName("pk_EmailId");

                entity.HasIndex(e => e.PhoneNumber)
                    .HasName("UQ__Users__85FB4E38BBA6F81B")
                    .IsUnique();

                entity.HasIndex(e => e.RoleId)
                    .HasName("ix_RoleId");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber).HasColumnType("numeric(12, 0)");

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("fk_RoleId");
            });
        }
    }
}
