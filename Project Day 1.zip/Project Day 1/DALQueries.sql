CREATE TABLE Roles
(
	[RoleId] TINYINT CONSTRAINT pk_RoleId PRIMARY KEY IDENTITY,
	[RoleName] VARCHAR(20) CONSTRAINT uq_RoleName UNIQUE
)
GO 

CREATE TABLE Users
(
	[EmailId] VARCHAR(50) CONSTRAINT pk_EmailId PRIMARY KEY,
	[Name] VARCHAR(30) NOT NULL,
	[PhoneNumber] NUMERIC(12) NOT NULL UNIQUE,
	[UserPassword] VARCHAR(15) NOT NULL,
	[RoleId] TINYINT CONSTRAINT fk_RoleId REFERENCES Roles(RoleId),
)
GO

CREATE TABLE Categories
(
	[CategoryId] BIGINT CONSTRAINT pk_CategoryId PRIMARY KEY IDENTITY,
	[CategoryName] VARCHAR(50) CONSTRAINT uq_CategoryName UNIQUE NOT NULL,
	[CategoryDescription] varchar(max) NOT NULL 
)
GO

CREATE TABLE Questions
(
	[QuestionId] BIGINT CONSTRAINT pk_QuestionId PRIMARY KEY IDENTITY,
	[QuestionDescription] VARCHAR(1000) NOT NULL UNIQUE,
	[CategoryId] BIGINT CONSTRAINT fk_CategoryId REFERENCES Categories(CategoryId),
	[EmailId] VARCHAR(50) CONSTRAINT fk_EmailId REFERENCES Users(EmailId)
)
GO

CREATE TABLE Answers
(
	[AnswerId] BIGINT CONSTRAINT pk_AnswerId PRIMARY KEY IDENTITY,
	[AnswerDescription] VARCHAR(1000) NOT NULL UNIQUE,
	[QuestionId] BIGINT CONSTRAINT fk_QuestionId REFERENCES Questions(QuestionId),
	[EmailId] VARCHAR(50) CONSTRAINT fk_EmailId1 REFERENCES Users(EmailId),
	[Rating] TINYINT CONSTRAINT chk_Rating CHECK (Rating IN (1,-1))
)
GO

CREATE TABLE Blogs
(
	[BlogId] BIGINT CONSTRAINT pk_BlogId PRIMARY KEY IDENTITY,
	[BlogName] VARCHAR(50) NOT NULL UNIQUE,
	[CategoryId] BIGINT CONSTRAINT fk_CategoryId1 REFERENCES Categories(CategoryId),
	[EmailId] VARCHAR(50) CONSTRAINT fk_EmailId2 REFERENCES Users(EmailId),
	[BlogDescription] varchar(max),
	[Rating] TINYINT CONSTRAINT chk_Rating1 CHECK (Rating IN (1,-1))
)
GO

CREATE TABLE SavedQuestions
(
	[SavedQuestionId] BIGINT CONSTRAINT pk_SavedQuestionId PRIMARY KEY IDENTITY,
	[QuestionId] BIGINT CONSTRAINT fk_QuestionId1 REFERENCES Questions(QuestionId),
	[EmailId] VARCHAR(50) CONSTRAINT fk_EmailId3 REFERENCES Users(EmailId)
)
GO

CREATE TABLE SavedBlogs
(
	[SavedBlogId] BIGINT CONSTRAINT pk_SavedBlogId PRIMARY KEY IDENTITY,
	[BlogId] BIGINT CONSTRAINT fk_BlogId REFERENCES Blogs(BlogId),
	[EmailId] VARCHAR(50) CONSTRAINT fk_EmailId4 REFERENCES Users(EmailId)
)
GO

CREATE INDEX ix_RoleId ON Users(RoleId)
CREATE INDEX ix_CategoryId ON Categories(CategoryId)
CREATE INDEX ix_QuestionId ON Questions(QuestionId)
CREATE INDEX ix_AnswerId ON Answers(AnswerId)
GO

SET IDENTITY_INSERT Roles ON
INSERT INTO Roles (RoleId, RoleName) VALUES (1, 'Admin')
INSERT INTO Roles (RoleId, RoleName) VALUES (2, 'Customer')
SET IDENTITY_INSERT Roles OFF
go

INSERT INTO Users(EmailId,[Name],PhoneNumber,UserPassword, RoleId) VALUES('IamAdmin@gmail.com','Simon',9899245845,'admin@1234',1)
INSERT INTO Users(EmailId,[Name],PhoneNumber,UserPassword, RoleId) VALUES('Franken@gmail.com','Frank',9999888845,'BSBEV@1234',2)
INSERT INTO Users(EmailId,[Name],PhoneNumber,UserPassword, RoleId) VALUES('Michael@gmail.com','Michael',8958688845,'mich@1234',2)
go

insert into Categories(CategoryName,CategoryDescription) values('Artificial Intelligence','dbhewjgayd fqxyewwwwwwwwwwwwwwwgq')


select * from Roles
select * from Users order by RoleId
select * from Categories
select * from Questions
select * from Answers
select * from Blogs
select * from SavedBlogs
select * from SavedQuestions